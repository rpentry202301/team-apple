<?php echo $__env->yieldContent('content'); ?>
<!-- table -->
<div class="row">
    <div class="table-responsive col-lg-offset-1 col-lg-10 col-md-offset-1 col-md-10 col-sm-10 col-xs-12">
        <h3 class="text-center">ショッピングカート</h3>
        <?php if(count($items) == 0): ?>
            <p><strong>カートに商品が存在しません</strong></p>
        <?php else: ?>
            <table class="table table-striped item-list-table">
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        </tr>
                        <tr>
                            <td>
                                <div class="center">
                                    <img src="../images/1.jpg" class="img-responsive img-rounded item-img-center"
                                        width="100" height="300" /><br />
                                    
                                    <?php echo e($items->item->name); ?>

                                </div>
                            </td>
                            <td>
                                <span
                                    class="price">&nbsp;<?php echo e($item->size); ?></span>&nbsp;&nbsp;<?php echo e($item->order_price ? $item->order_price : 'No topping'); ?>円
                                &nbsp;&nbsp;<?php echo e($item->quantity); ?>個
                            </td>
                            <td>
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $item->cartToppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartTopping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($cartTopping->topping ? $cartTopping->topping->name : 'No topping'); ?>

                                        </li>
                                </ul>
                            <td>
                                <div class="text-center"><?php echo e($cartTopping->total_topping_price); ?>円</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('cart.delete')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="text-center">
                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                <button type="submit" class="btn btn-primary">削除</button>
                            </div>
                        </form>
                    </td>
                    </tr>
                </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<div class="row">
    <div class="col-xs-offset-2 col-xs-8">
        <div class="form-group text-center">
            <span id="total-price">消費税：<?php echo e($tax); ?>円</span><br />
            <span id="total-price">ご注文金額合計：<?php echo e($total_price); ?>円 (税込)</span>
        </div>
    </div>
</div>

<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/components/cart_list.blade.php ENDPATH**/ ?>