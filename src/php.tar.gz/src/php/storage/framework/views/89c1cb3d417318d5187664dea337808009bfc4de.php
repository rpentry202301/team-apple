hello
<?php /**PATH /var/www/html/resources/views/items/items.blade.php ENDPATH**/ ?>