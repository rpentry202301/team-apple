<h1>**** ご注文内容 ****</h1><br>
<br>
<div>
    <h2>注文者氏名</h2>
     <?php echo e($userName); ?><br>
    <br>
</div>
<div>
    <h2>ご注文内容</h2>
    <table>
<?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($item->order_name); ?></th>
            <th><?php echo e($item->quantity); ?>点</th>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<div>
    <h2>合計金額</h2>
    <?php echo e($totalPrice); ?>円<br>
    <br>
</div>
<h2>配送先氏名</h2>
 <?php echo e($destinationName); ?><br>

<h2>配送先住所</h2>
<?php echo e($destinationZipcode); ?><br>
<?php echo e($destinationPrefectures); ?><br>
<?php echo e($destinationMunicipalities); ?><br>
<?php echo e($destinationAddressLine1); ?><br>
<?php echo e($destinationAddressLine2); ?><br>

<h2>お届け予定時刻</h2>
<?php echo e($deliveryTime); ?> にお届けします！<br>

<h2>次回ご利用可能なクーポンコード</h2>
【thankyou40】<br>

</html>

<?php /**PATH /var/www/html/resources/views/orderConfirmMail/mail.blade.php ENDPATH**/ ?>