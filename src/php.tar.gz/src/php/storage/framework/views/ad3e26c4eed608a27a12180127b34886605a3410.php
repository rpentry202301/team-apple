<?php $__env->startSection('title'); ?>
商品一覧ページ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-offset-3 col-lg-6 col-md-offset-2 col-md-8 col-sm-10 col-xs-12">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="panel panel-default">
    <div class="panel-heading">
        <div class="panel-title">商品を検索する</div>
      </div>
      <div class="panel-body">

        <form  action="/search" class="form-horizontal" >
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="code" class="control-label col-sm-2">キーワード</label>
            <div class="col-sm-9">
              <input type="text" name="keyword" id="keyword" class="form-control input-sm" />
            </div>
          </div>
          <div class="text-center">
            <button type="submit" value="検索" class="btn btn-primary">
              検索
            </button>
            <button type="reset" value="クリア" class="btn btn-default">
              クリア
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="table-responsive col-lg-offset-1 col-lg-10 col-md-offset-1 col-md-10 col-sm-10 col-xs-12">
    <!--繰り返し処理で商品情報一覧を表示-->
    <table class="table table-striped item-list-table">
      <tbody>
        <tr>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <th>
            <a href="/item/<?php echo e($item->id); ?>">
              <img src="../images/<?php echo e($item->id); ?>.jpg" class="img-responsive img-rounded item-img-center" width="200" height="600" /> </a><br />
            <a href="/item/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a><br />
            <span class="price">&nbsp;М&nbsp;</span>&nbsp;&nbsp;<?php echo e($item->price_m); ?>(税抜)<br />
            <span class="price">&nbsp;Ｌ</span>&nbsp;&nbsp;<?php echo e($item->price_l); ?>(税抜)<br />
          </th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
      </tbody>
     </table>
    <!-- ページングボタン -->
    <div class="text-center">
      <?php echo e($items->withQueryString()->links()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/items/item_list.blade.php ENDPATH**/ ?>