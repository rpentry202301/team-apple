aa
aaaaa
aaaaa
<?php /**PATH /var/www/html/resources/views/hello.blade.php ENDPATH**/ ?>