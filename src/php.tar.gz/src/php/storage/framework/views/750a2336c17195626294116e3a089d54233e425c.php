<footer class="bg-light py-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <p>&copy; 2023 Example Company. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH /var/www/html/resources/views/components/footer.blade.php ENDPATH**/ ?>